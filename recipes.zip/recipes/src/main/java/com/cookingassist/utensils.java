package com.cookingassist;

public class utensils {
    private final String name;

    public utensils(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
}
