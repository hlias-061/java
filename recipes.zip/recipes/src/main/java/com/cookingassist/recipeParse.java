package com.cookingassist;

import java.io.*;
import java.util.regex.*;

public class recipeParse {
    public static recipe parseRecipe(String fileName) throws IOException {
        recipe recipe = new recipe(fileName);
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            Pattern ingredientPattern = Pattern.compile("@(\\w+\\s*\\w*)\\{(\\d+(\\.\\d+)?)(%\\w+)?}");
            Pattern utensilPattern = Pattern.compile("#(\\w+\\s*\\w*)");
            Pattern timePattern = Pattern.compile("~\\{(\\d+)%\\w+}");

            while ((line = reader.readLine()) != null) {
                Matcher ingredientMatcher = ingredientPattern.matcher(line);
                while (ingredientMatcher.find()) {
                    String name = ingredientMatcher.group(1).trim();
                    double quantity = Double.parseDouble(ingredientMatcher.group(2));
                    String unit = ingredientMatcher.group(4) != null ? ingredientMatcher.group(4).substring(1) : "";
                    recipe.addIngredient(new ingredients(name, quantity, unit));
                }

                Matcher utensilMatcher = utensilPattern.matcher(line);
                while (utensilMatcher.find()) {
                    recipe.addUtensil(new utensils(utensilMatcher.group(1).trim()));
                }

                Matcher timeMatcher = timePattern.matcher(line);
                if (timeMatcher.find()) {
                    int time = Integer.parseInt(timeMatcher.group(1));
                    recipe.addStep(new steps(line.trim(), time));
                } else if (!line.isBlank()) {
                    recipe.addStep(new steps(line.trim(), 0));
                }
            }
        }
        return recipe;
    }
}
