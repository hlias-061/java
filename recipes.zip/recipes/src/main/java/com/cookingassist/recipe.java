package com.cookingassist;

import java.util.*;

public class recipe {
    private final String name;
    private final List<ingredients> ingredients = new ArrayList<>();
    private final List<utensils> utensils = new ArrayList<>();
    private final List<steps> steps = new ArrayList<>();

    public recipe(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void addIngredient(ingredients ingredient) {
        ingredients.add(ingredient);
    }

    public void addUtensil(utensils utensil) {
        utensils.add(utensil);
    }

    public void addStep(steps step) {
        steps.add(step);
    }

    public List<ingredients> getIngredients() {
        return ingredients;
    }

    public List<utensils> getUtensils() {
        return utensils;
    }

    public List<steps> getSteps() {
        return steps;
    }

    public void display() {
        System.out.println("Recipe: " + name);
        System.out.println("Ingredients:");
        ingredients.forEach(System.out::println);
        System.out.println("\nUtensils:");
        utensils.forEach(System.out::println);
        System.out.println("\nSteps:");
        steps.forEach(System.out::println);
    }

    public void executeSteps() {
        for (steps step : steps) {
            step.execute();
        }
    }
}
