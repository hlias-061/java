package com.cookingassist;

import java.util.*;

public class listGen {
    public static void generate(List<recipe> recipes) {
        Map<String, ingredients> shoppingList = new HashMap<>();

        for (recipe recipe : recipes) {
            for (ingredients ingredient : recipe.getIngredients()) {
                shoppingList.merge(ingredient.getName(),
                        new ingredients(ingredient.getName(), ingredient.getQuantity(), ingredient.getUnit()),
                        (existing, newIngredient) -> {
                            existing.addQuantity(newIngredient.getQuantity());
                            return existing;
                        });
            }
        }

        System.out.println("Shopping List:");
        shoppingList.values().forEach(System.out::println);
    }
}
