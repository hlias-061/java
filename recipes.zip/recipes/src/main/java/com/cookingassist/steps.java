package com.cookingassist;

import gr.hua.dit.oop2.countdown.Countdown;
import gr.hua.dit.oop2.countdown.CountdownFactory;

public class steps {
    private final String description;
    private final int time; // in minutes

    public steps(String description, int time) {
        this.description = description;
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public int getTime() {
        return time;
    }

    public void execute() {
        System.out.println(description);
        if (time > 0) {
            Countdown countdown = CountdownFactory.countdown(time * 60); // Μετατροπή λεπτών σε δευτερόλεπτα
            countdown.start();
            while (countdown.secondsRemaining() > 0) {
                System.out.printf("Time remaining: %d seconds%n", countdown.secondsRemaining());
                try {
                    Thread.sleep(1000); // Κάθε 1 δευτερόλεπτο
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            countdown.stop();
            System.out.println("Step complete!");
        }
    }

    @Override
    public String toString() {
        return description + " (Time: " + time + " minutes)";
    }
}
