package com.cookingassist;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        if (args.length == 0) {
            printUsage();
            return;
        }

        if (args[0].equals("-list")) {
            List<String> fileNames = Arrays.asList(Arrays.copyOfRange(args, 1, args.length));
            generateShoppingList(fileNames);
        } else if (args[0].equals("-execute")) {
            executeRecipe(args[1]);
        } else {
            displayRecipe(args[0]);
        }
    }

    private static void printUsage() {
        System.out.println("Usage:");
        System.out.println("java -jar recipes.jar <recipe.cook>");
        System.out.println("java -jar recipes.jar -list <recipe1.cook> <recipe2.cook> ...");
        System.out.println("java -jar recipes.jar -execute <recipe.cook>");
    }

    private static void displayRecipe(String fileName) {
        try {
            // Προσθέτουμε τη διαδρομή στον φάκελο "recipes"
            String path = Paths.get("recipes", fileName).toString();
            recipe recipe = recipeParse.parseRecipe(path);
            recipe.display();
        } catch (IOException e) {
            System.err.println("Error reading file: " + fileName);
        }
    }

    private static void generateShoppingList(List<String> fileNames) {
        try {
            List<recipe> recipes = new ArrayList<>();
            for (String fileName : fileNames) {
                // Προσθέτουμε τη διαδρομή στον φάκελο "recipes"
                String path = Paths.get("recipes", fileName).toString();
                recipes.add(recipeParse.parseRecipe(path));
            }
            listGen.generate(recipes);
        } catch (IOException e) {
            System.err.println("Error processing files.");
        }
    }

    private static void executeRecipe(String fileName) {
        try {
            // Προσθέτουμε τη διαδρομή στον φάκελο "recipes"
            String path = Paths.get("recipes", fileName).toString();
            recipe recipe = recipeParse.parseRecipe(path);
            recipe.executeSteps();
        } catch (IOException e) {
            System.err.println("Error reading file: " + fileName);
        }
    }
}
